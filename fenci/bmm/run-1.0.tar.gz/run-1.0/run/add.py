def get():
    return 1